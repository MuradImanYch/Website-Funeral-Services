<div class='socNetWrap'>
    <a href="https://www.facebook.com/ritualxidmet" target='_blank'><img src="<?php load_images('ico/fb.png') ?>" alt="fb" /></a>
    <a href="https://www.instagram.com/ritual_xidmetler" target='_blank'><img src="<?php load_images('ico/instagram.png') ?>" alt="instagram" /></a>
    <a href="https://www.youtube.com/channel/UCnuDZyPUgVD1LYk7pYjFBRw" target='_blank'><img src="<?php load_images('ico/yt.png') ?>" alt="yt" /></a>
    <a href="https://api.whatsapp.com/send?phone=+994552666878&text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5.%20%D0%A3%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B2%D0%BE%D0%BF%D1%80%D0%BE%D1%81!" target='_blank'><img src="<?php load_images('ico/wp.png') ?>" alt="wp" /></a>
    <a href="https://telegram.me/+994552666878" target='_blank'><img src="<?php load_images('ico/tg.png') ?>" alt="tg" /></a>
</div>